# Hook25MB
A very simple website that lets you upload files to webhook that are up to 25MB.

**EDIT (13th October 2024)**: Now allows to send files to specific threads (by thread ID)

> ![image](https://github.com/user-attachments/assets/0ee6e209-1bb2-480d-bf53-519c14fe0be3)


